CREATE FUNCTION getParentCatalog(catalogId BIGINT)
  RETURNS VARCHAR(100)
  BEGIN
#定义一个最终的拼凑成的父分类id字符串
declare resultStr varchar(100);
#临时的父分类id变量
declare tempParentId bigint;
#初始化这两个变量
set resultStr = "";
set tempParentId = catalogId;

while tempParentId is not null
do
	set resultStr = concat(resultStr,",",tempParentId);
	select p_id into tempParentId from catalog where id = tempParentId;
end while;
return resultStr;

END;
